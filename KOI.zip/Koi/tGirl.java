package Koi;

public class tGirl extends Girl {

	/*
	[상속 ] 
	int Att; //매력
	int Lv; //  
	int Hp; // 체력
	Stirng Type;
	*/ 
	   

 
tGirl ( int Hp, int Exp, int Lv,String Type)
{	
	super(Hp,Exp,Lv,Type);
 
	
}

tGirl (  )
{ 
	int Hp=50;
	int Exp=0;
	int Lv=1;
	String Type="츤데레";
	
}


	//void talk(tGirl tGirl) {System.out.println(Type+"(은)는"+" "+Name+"와(과) 조우했다 \n 나니요 ! 흥  ");
	
	//}
	
	void talk1() {
		System.out.println("흥! 나니욧!");
	
	}
	void talk2() {
		System.out.println("특, 특별히 널 만나러온 건 아니야! 흥 ! ");
	
	}
	void talk3() {
		System.out.println("보 보고싶었어... \n 이런말을 하게 한 건 네가 처음이니까 책임져! ");
	
	}
	void talk4() {
		System.out.println("너~~~~~무 좋아!! ");
	
	}
	//void PreTalk1() {
 
	//	System.out.println("정.말.싫.어. !! 너나 가져 \n "+Type+" 은(는) 선물을 던지고 사라졌다.");
	
	//}
	
	void PreTalk2() {
		System.out.println(" 흥, 특별히 받아주는거야  ");
	
	}
	void PreTalk3() {
		System.out.println(" 고, 고마워 ");
	
	}
	
	void Pretalk4() {
		System.out.println("너~~~~~무 좋아!!♡♡♡ ");
	
	}
	
	}

