package Koi;

public class mmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		tGirl t=new tGirl();
		System.out.println(t.Type);
		
	}

}
