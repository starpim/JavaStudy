package Koi;

public class Girl extends Unit {
	
	private String Type;
    
	Girl (int Att, int Lv, int Hp, String Type)
	{
		super(Att,Lv,Hp);
		this.Type=Type; //호감도 레벨 
	}
	
	Girl(){
		
	}
	
	void talk1() {
			System.out.println("흥! 나니욧!");
		
	}
	void talk2() {
		System.out.println("특, 특별히 널 만나러온 건 아니야! 흥 ! ");
	
}
	void talk3() {
		System.out.println("보 보고싶었어... \n 이런말을 하게 한 건 네가 처음이니까 책임져! ");
	
}
	void talk4() {
		System.out.println("너~~~~~무 좋아!! ");
	
}
	}

	



/*
[상속 ] 
int Att; //매력
int Lv; //  
int Hp; // 체력

*/ 
   