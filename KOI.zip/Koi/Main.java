package Koi;

import java.util.Scanner;

import abc.Otaku;
import abc.ikeMan;
import abc.normalMan;

public class Main {

	public static void main(String[] args) {
		 
		Unit u=new Unit();
		Charactor c = new Charactor();
		ikeMan ike=new ikeMan();
        Otaku ota=new Otaku();
        normalMan no=new normalMan();
		tGirl t=new tGirl("미나세이오리");
		t.talk();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("플레어블 캐릭터를 선택해 주세요 1. 존잘남 2. 오타쿠 3. 평범남");
		int select= sc.nextInt();
	 
		
		if(select==1){ 
			System.out.println("존잘남을 선택했습니다.");
			ike.talk();
			t.talk4();
			System.out.println("선물을 선택해 주세요 :1.케이크  2.나이프 3. 화장품 4. 책 ");
			int a=sc.nextInt();
			switch(a) {
				case 1:
					ike.Cake();	
					t.Pretalk4();
					ike.result();
					break;
				
				case 2:
					ike.Knife();
					t.Pretalk4();
					ike.result();
					break;
				case 3:
					ike.Cosme();
					t.Pretalk4();
					ike.result();
					break;
				
				case 4:
					ike.Book();
					t.Pretalk4();
					ike.result();
					break;
			}}
		else if(select==2) { 
		 
			System.out.println("오타쿠를 선택했습니다.");
			ota.talk();
			System.out.println("선물을 선택해 주세요 :1.케이크  2.나이프 3. 화장품 4. 책 ");
			 int a=sc.nextInt();
			switch(a) {
				case 1:
					System.out.println("케이크를 선물했습니다.");
					t.PreTalk1();
					ike.exp-=999;
					break;
				
				case 2:
					System.out.println("나이프를 선물했습니다.");
					t.PreTalk1();
					ike.exp-=999;
					break;
				case 3:
					System.out.println("화장품을 선물했습니다.");
					t.PreTalk1();
					ike.exp-=999;
					break;
				
				case 4:
					System.out.println("책을 선물했습니다.");
					t.PreTalk1();
					ike.exp-=999;
					break;
			}}
		else if(select==3) {
			System.out.println("평범남을 선택했습니다.");
			System.out.println("선물을 선택해 주세요 :1.케이크  2.나이프 3. 화장품 4. 책 ");
			int a=sc.nextInt();
			switch(a) {
				case 1:
					
			    no.Cake();
				no.tGirl();
					 
					break;
				
				case 2:
					no.Knife();
					no.tGirl();
					 
					break;
				case 3:
					no.Cosme();
					no.tGirl();
					 
					break;
				
				case 4:
					no.Book();
					no.tGirl();
					 
					break;
			}
			}
		}
		
		

	}
 