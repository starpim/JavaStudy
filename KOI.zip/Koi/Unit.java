package Koi;

public class Unit {
	
	private int Att; //매력
	private int Lv; //  
	private int Hp; // 체력
	
	//행동 : 공격 OR 정보 
	   
	Unit(){}
	
	Unit ( int Att, int Lv, int Hp )
	{
	this.Att=Att;
	this.Lv=Lv;
	this.Hp=Hp;
	}

 
}
