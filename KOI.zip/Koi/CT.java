package Koi;

public class CT extends Unit {
	
	private int Exp;
	
	CT(int Att, int Hp, int Lv )
	{
	 super(Att,Hp,Lv);
	
	 this.Exp=1;
	 
	}
	
	
	
	CT(){}
	//void lvUp() {
		//if(this.Exp>=100) {
		//	Exp-=100;
		//	Lv+=1;
	//	}
		 
	}
	
 



/*
[상속 ] 
int Att; //매력
int Lv; //  
int Hp; // 체력

*/ 
   