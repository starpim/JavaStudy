package JAVA0808;

import java.util.Scanner;

public class Res { 
	private String Name; //식당이름 
	private int seat; //잔여수 
	private int B; 
	private String Customer;
	
	Scanner sc = new Scanner(System.in);

	Res(){
		this.Name=Name; //식당이름 
		this.seat=seat; //잔여수 
		this.B= B; 
		this. Customer=Customer ;
	}
	Res(String Name, int seat){
		this.Name=Name;
		this.seat=seat;
		
	}
	
	Res(int seat) {
		
		this.seat=seat;
	}
	
	Res(String Name, String Customer,int seat){
		this.Name=Name;
		this.Customer=Customer;
		this.seat=seat;
	}
	
	String getCustomer() {
		return Customer;
	}
	int  getRes() {
		return  this.seat;
	}
	
	int getSeat(int seat) {
		return seat=this.seat;
	}

	
	
	String getName() {
		 
		return  Name ;
	}
	

	void ResName( ) {
		System.out.println( Name+"에 오신 것을 환영합니다. \n 현재 예약 가능한 이곳의 잔여 좌석수는 "+ seat+"석 입니다.");
		
	}
	
	
	
	void book ( int Book    ) {
		
		if(Book<0||Book>seat) {
			
			System.out.println("좌석이 부족합니다. 다시 확인해 주세요.");
			return;
	}
	    
		seat -=Book;
	
	return; 
	}
	
	
	
	
	
}
	
	 