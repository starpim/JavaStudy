package JAVA0808;

public class resMain {


	public static void main(String[] args) {
		
		Res sea=new Res("씨네드쉐프 용산점",100);
		Res sea2=new Res("씨네드쉐프 압구정점",100);  
		
//////////////////////////////////////////////////////////////////////////////////////////////////
		
		sea.ResName(); //씨네드쉐프 용산점 ** 
		Cus kim=new Cus("김한나",20); //김한나 2명 예약
	 	Cus you=new Cus("유경미",40); // 유경미 4명 예약
 		Cus jang=new Cus("장신영",40); // 유경미 4명 예약
 		Cus cha=new Cus("차은미",40); // 유경미 4명 예약
 		System.out.println("--------------------------------------.");
		kim.book(sea ); //잔여좌석 출력 
		you.book(sea);//잔여좌석 출력 
		jang.book(sea );//잔여좌석 출력 
		cha.book(sea );//잔여좌석 출력 
		System.out.println("--------------------------------------.");
		
		sea2.ResName(); // 씨네드쉐프 압구정 점 
		Cus a=new Cus();
		a.name(); // 예약자 이름 입력 
		a.book(sea2 ); // 잔여좌석 출력. 
		
//////////////////////////////////////////////////////////////////////////////////////////////////			
 
	}
}
