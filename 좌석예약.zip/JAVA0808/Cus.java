package JAVA0808;

import java.util.Scanner;

public class Cus extends Res{ 
	
	private int Book;
	private String Name;
	Scanner sc = new Scanner(System.in);
	
	Cus( String Name, int Book,int seat){
		super(seat);
		this.Name=Name;
		this.Book=Book;
		
	}
	
	Cus(String Name, int seat, int B, String Customer){
	
	}
	
	Cus(  String Name, int Book){
		 
		this.Name=Name;
		this.Book=Book;
		
	}
	
	Cus( ){
		 
		this.Name=Name;
		this.Book=Book;
		
	}
	
 
	
	 int getBook() {
		 return Book;
	 }
	 
	 int test() {
		 return super.seat;
	 }
	 
	 
	 void name( ) {
		 System.out.println("성함을 입력해 주세요: ");
		 Name=sc.next();
			System.out.println("예약 인원을 입력해 주세요: ");
			Book=sc.nextInt();
			
	 }
 

		void book ( Res Res ) {
			 
			 
			if(this.Book<0||this.Book> Res.seat  ) {
				
				 
				System.out.println("좌석이 부족합니다. 다음에 이용해 주세요." );
				return  ;
				
		}
			 
			  Res.seat -= Book;
			  
			System.out.println(Name+ " 고객님 "+Book+ "석 예약성공! 이용해 주셔서 감사합니다.\n 잔여좌석:"+  Res.seat);
		
		 
		 return   ;
		 
		
		}
	
 //Book=2<0 거나, 2>100 면? if 실행. 
 
	
	
	
}
	
	 